# Codex Implementation Task

Build the first playable prototype of the Emoji Wager Game.

## Deliverable

A working browser game with one implemented minigame: four-direction emoji sorting.

## Implementation order

1. Load and validate `data/items.json` and `data/category_selectors.json`.
2. Implement selector matching over tags, colors, kind, and exclusions.
3. Generate a valid sorting board with eight groups of four unique glyphs.
4. Render the board with two groups per direction and a center prompt queue.
5. Support arrow-key and click/touch input.
6. Animate correct and wrong dispatches.
7. Track completion time and streak.
8. Compute Club and Heart thresholds from game memory.
9. Award Diamonds/Clubs and subtract Hearts according to `docs/04_scoring_memory_and_economy.md`.
10. Persist state to localStorage.
11. Add tests matching `docs/08_acceptance_tests.md`.

## Do not implement yet

- Real-money wagering
- Multiplayer
- Login/accounts
- Narrative village/trust systems
- AI-generated categories during play
- Additional minigames beyond stubs/placeholders
