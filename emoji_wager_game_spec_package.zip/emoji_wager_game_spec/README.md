# Emoji Wager Game Specification Package

This repository is a Codex-ready specification package for a browser-based, single-player, abstract skill-and-wager game.

The first implemented minigame should be **four-direction emoji sorting**.  The player sees eight temporary groups of four glyphs, with two groups assigned to each screen edge.  One glyph appears in the center at a time.  The player dispatches it with arrow keys or directional clicks.  Completion time is the score.

The game has four resources:

- **Hearts**: tolerance for slow or deteriorating performance.
- **Diamonds**: currency used for recovery, upgrades, Spades, and unlocks.
- **Clubs**: reward for beating the aggressive improvement line.
- **Spades**: productive assets that increase Diamond income but do not directly make the skill test easier.

Read all documents in `/docs` before implementing.  Treat `docs/08_acceptance_tests.md` as the definition of done for the first playable version.

## Suggested stack

- React + TypeScript + Vite
- Local state persisted in `localStorage`
- Seeded pseudo-random round generation
- Unit tests for selectors, board generation, memory, and scoring
- No backend, no authentication, no real-money wagering

## Important data files

- `data/items.json`: flat glyph catalog with descriptive tags and colors.
- `data/category_selectors.json`: curated selectors used to form sorting groups.
- `data/default_state.json`: starter resource and memory state.
