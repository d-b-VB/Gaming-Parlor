# Scoring, Memory, and Economy

## Score direction

For sorting, lower time is better.

## Game memory

Each game type has a fixed-size memory of recent score entries.  Use 20 entries in the first prototype.

Each memory entry has:

- `gameId`
- `timeSeconds`
- `entryType`: `actual` or `rest`
- `createdAt`

Actual entries come from completed rounds.  Rest entries are artificial easing entries applied to unplayed games.

## Updating memory after a completed round

When the player completes game `G` with time `T`:

1. Add an `actual` memory entry with time `T` to game `G`.
2. For every other unlocked game, add a `rest` entry equal to that other game's current worst remembered time.
3. Trim each game's memory to the most recent 20 entries.

For sorting-only prototype builds, step 2 should be implemented in the model but has no effect until more games exist.

## Why rest entries exist

Rest entries are not punishments and should not be described as bad scores.  They represent expectations cooling off while a game is neglected.  They lower the bar for Heart safety and Club improvement when the player returns.

## Thresholds

For each game, compute thresholds from that game's current memory.  Lower time is better.

- **Club threshold**: 25th percentile of memory times.
- **Heart threshold**: 50th percentile of memory times, i.e. median.

If fewer than 5 memory entries exist, use starter defaults:

- Sorting Club threshold: 50 seconds.
- Sorting Heart threshold: 70 seconds.

## Round outcome

Given completion time `T`:

- If `T <= clubThreshold`: award Clubs and Diamonds.
- Else if `T <= heartThreshold`: award ordinary Diamonds, no Heart loss.
- Else: lose 1 Heart and award reduced Diamonds.

## New worst time

If `T` is worse than every actual score currently in that game's memory, lose 2 Hearts total instead of 1 Heart.  Rest entries do not count as actual scores for this comparison.

## Diamond payout

Suggested first-prototype formula:

```text
baseDiamonds = 2
spadeBonus = ownedSpades
clubBonus = T <= clubThreshold ? 2 : 0
heartPenalty = T > heartThreshold ? -1 : 0
payout = max(0, baseDiamonds + spadeBonus + clubBonus + heartPenalty)
```

## Club payout

Suggested first-prototype formula:

```text
clubsGained = T <= clubThreshold ? 1 : 0
```

If `T` beats the best actual time in memory, award 2 Clubs instead of 1.

## Purchases

First-prototype purchases:

- Restore 1 Heart: 5 Diamonds.
- Buy 1 Spade: cost starts at 10 Diamonds and increases by 1.6x per Spade, rounded up.
- Increase max Hearts by 1: cost starts at 20 Diamonds and doubles each time.

These numbers are placeholders and should be constants in one economy config file.
