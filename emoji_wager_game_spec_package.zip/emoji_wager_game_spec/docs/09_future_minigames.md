# Future Minigames

The system should eventually support multiple games.  Each game has its own memory and thresholds.

## Tile packing

The player fills a target silhouette with tetromino-like or hexomino-like pieces.  Score is completion time.  Mistakes add time through piece return animations.

## Sequence recall

The player watches a sequence of symbols, directions, colors, or sounds and reproduces it.  Score may be time to complete a fixed set of sequences or maximum sequence length under a timer.

## Typing

The player transcribes short strings accurately.  Score is completion time for a fixed prompt set.  Wrong characters require correction or add queue delay.

## Rotation economy

When multiple games exist, completing one game adds a rest entry to every other unlocked game.  This cools their thresholds and encourages rotating between game types.
