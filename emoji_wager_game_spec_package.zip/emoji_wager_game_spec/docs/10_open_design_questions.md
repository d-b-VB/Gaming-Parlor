# Open Design Questions

These are intentionally not blockers for the first prototype.

1. Should Clubs eventually be spendable, or should they remain a rank/progress currency?
2. Should Heart loss reduce Diamond payout, or should Heart loss and payout be independent?
3. Should the player be allowed to choose a harder Club line before a round?
4. Should upgrades affect animation speed only, or can they also affect queue rules?
5. Should exact-palette color categories be shown as text labels, color swatches, or both?
6. Should ambiguous boards be rejected strictly, or should some ambiguity be allowed at higher difficulty?
7. Should flags be common in normal play or reserved for geography/color-heavy rounds?
