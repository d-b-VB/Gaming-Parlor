# Game Rules and Suit Meanings

## Hearts

Hearts are the player's tolerance for slow or deteriorating performance.

A Heart is lost when the player finishes after the Heart threshold for the current round.  If the player runs out of Hearts, the first prototype should show a simple game-over or reset panel.  Do not delete history automatically unless the user chooses reset.

Hearts are not village trust, hit points in combat, or physical health.  They are an abstract loss buffer.

## Diamonds

Diamonds are liquid currency.

Diamonds can be used to:

- Restore Hearts.
- Increase maximum Hearts.
- Buy Spades.
- Buy sorting-game animation upgrades.
- Unlock additional game types in future versions.

The first prototype should implement at least restoring Hearts and buying Spades.  Other purchases can be visible but disabled.

## Clubs

Clubs are rewards for beating the aggressive improvement target.  They represent nerve, upside, and demonstrated improvement.

For the first prototype, Clubs should be accumulated as a score/rank currency.  They do not need to be spendable.  Later versions may use Clubs to unlock more aggressive wager modes.

## Spades

Spades are productive assets.

Each owned Spade increases the Diamond payout from completed games.  Spades do not directly improve player input speed, reduce mistakes, or change category generation.

## No real-money wagering

All wagering language is metaphorical and uses only in-game resources.
