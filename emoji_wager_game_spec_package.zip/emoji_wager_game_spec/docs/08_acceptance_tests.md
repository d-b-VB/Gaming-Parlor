# Acceptance Tests

## Data and selectors

- The app loads `data/items.json` without runtime errors.
- The app loads `data/category_selectors.json` without runtime errors.
- A selector with `requiredTags` matches items containing all required tags.
- A selector with `containsColors` matches items containing all requested colors.
- A selector with `excludesColors` rejects items containing excluded colors.
- A selector with `exactColors` only matches items with exactly that color set.

## Board generation

- A new sorting round contains exactly 8 groups.
- Each group contains exactly 4 items.
- Each direction has exactly 2 groups.
- The board contains exactly 32 unique glyphs.
- A glyph never appears in two active groups.
- The generated prompt queue initially contains all 32 glyphs.
- Board generation is reproducible from a stored seed.

## Gameplay

- Arrow keys dispatch the center glyph in the corresponding direction.
- Clicking/tapping a directional zone dispatches the center glyph in that direction.
- A correct answer removes that glyph from the queue.
- A wrong answer sends that glyph to the back of the queue.
- The timer does not pause for correct or wrong answers.
- A correct streak increments after correct answers.
- A wrong answer resets the streak to zero.
- The round ends only when all 32 glyphs have been correctly sorted.

## Economy and memory

- Completion time is recorded as an actual memory entry.
- The Club threshold is the 25th percentile of memory times.
- The Heart threshold is the median of memory times.
- Finishing before or at the Club threshold awards Clubs.
- Finishing after the Heart threshold loses Hearts.
- Finishing worse than every actual memory entry loses 2 Hearts total.
- Buying a Spade increases future Diamond payouts.
- Restoring a Heart spends Diamonds and cannot exceed max Hearts.
- State persists after page reload.

## Non-goals

- The prototype does not need multiplayer.
- The prototype does not need real money.
- The prototype does not need a backend.
- The prototype does not need all future minigames implemented.
