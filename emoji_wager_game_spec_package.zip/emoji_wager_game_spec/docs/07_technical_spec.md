# Technical Specification

## Stack

Use React, TypeScript, and Vite unless the user specifies otherwise later.

## State

Persist all player state to `localStorage`:

- Resources: Hearts, max Hearts, Diamonds, Clubs, Spades.
- Game memories.
- Upgrade purchases.
- Unlocked game types.
- Event log of completed rounds.

## Determinism

Use a seedable pseudo-random number generator for round generation.  Store the seed with each round so boards can be reproduced.

## Validation

On app startup:

- Validate that every item has `id`, `glyph`, `name`, `kind`, `tags`, and `colors`.
- Validate that every selector has at least 4 eligible items, or mark it disabled.
- Validate that generated boards have 8 groups, 4 items per group, and 32 unique glyphs.

## Suggested modules

```text
src/data/loadCatalog.ts
src/game/selectors.ts
src/game/generateBoard.ts
src/game/scoring.ts
src/game/memory.ts
src/game/economy.ts
src/components/SortingGame.tsx
src/components/ResourceBar.tsx
src/components/DirectionalZone.tsx
src/components/PostRoundSummary.tsx
```

## Testing

Use unit tests for pure logic:

- Selector matching.
- Color exact/contains/excludes behavior.
- Board generation uniqueness.
- Threshold calculation.
- Memory updates.
- Economy payouts.

Animation tests are not required for the first prototype.
