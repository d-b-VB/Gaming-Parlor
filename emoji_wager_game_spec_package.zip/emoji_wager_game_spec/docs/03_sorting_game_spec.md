# Sorting Game Specification

## Round structure

A sorting round contains:

- 8 active groups.
- 4 glyphs per group.
- 32 unique glyph prompts total.
- 4 directions: up, down, left, right.
- 2 groups assigned to each direction.

The initial prototype should show all groups around the edges before and during play.  This is a memory/speed game, not a hidden-information game.

## Controls

Keyboard:

- ArrowUp sends the center glyph up.
- ArrowDown sends the center glyph down.
- ArrowLeft sends the center glyph left.
- ArrowRight sends the center glyph right.

Mouse/touch:

- Clicking or tapping a directional zone sends the center glyph in that direction.

## Correct input

When the chosen direction is correct:

1. The center glyph moves toward the selected edge.
2. The streak increases by 1.
3. The next glyph enters the center.
4. Correct movement and next-entry animation may speed up as streak increases.

The timer never pauses.

## Wrong input

When the chosen direction is wrong:

1. The center glyph begins moving toward the chosen edge.
2. It is visibly rejected with a brief shake, flash, or bounce.
3. The streak resets to 0.
4. The glyph moves to the back of the queue.
5. The next glyph enters the center.

The timer never pauses.

## Queue behavior

Each of the 32 glyphs starts in the queue once.  Correctly sorted glyphs leave the queue permanently.  Wrongly sorted glyphs are appended to the back of the queue.  The round ends when all 32 glyphs have been correctly sorted.

## Score

The score is completion time in seconds.  Lower is better.

The game may show mistakes and streaks, but the economy should use completion time as the scoring value.

## Streak effects

Streak should affect game feel, not correctness.

Suggested first-prototype values:

- Base correct-exit duration: 220 ms.
- Base next-entry duration: 160 ms.
- Each streak step reduces these durations by 3%, capped at 45% reduction.
- Wrong answers reset streak to 0.

Upgrades may later improve these values.
