# Content Generation

## Data philosophy

Items are not arranged into a tidy taxonomy.  Each item has many descriptive tags.  Tags are cross-cutting and non-exclusive.

A penguin can be `animal`, `bird`, `vertebrate`, `polar`, `cold`, `land`, `sea`, `black`, and `white`.

A flag can be `flag`, `island`, `Europe`, `subpolar`, `cross`, and have colors `blue`, `red`, and `white`.

## Items

Each item in `data/items.json` has:

- `id`: stable string identifier.
- `glyph`: displayed symbol.
- `name`: human-readable name.
- `kind`: `emoji`, `flag`, or `symbol`.
- `tags`: flat descriptive tags.
- `colors`: atomic colors where relevant.

## Selectors

Groups are built from selectors.  A selector may require tags, exclude tags, require colors, exclude colors, require exact colors, require color count, or limit item kind.

Examples:

```json
{ "requiredTags": ["arthropod"] }
```

```json
{ "exactColors": ["red", "white"] }
```

```json
{ "containsColors": ["red"], "excludesColors": ["blue"] }
```

## Board generation algorithm

1. Load curated selectors from `data/category_selectors.json`.
2. Filter to selectors with at least 4 eligible items.
3. Pick 8 selectors for the board.
4. Prefer known opposite pairs across opposite directions.
5. For each selector, choose 4 unique items.
6. No glyph may appear twice on the same board.
7. Avoid choosing an item for one group if it also matches another active group, unless no valid board can be generated after retries.
8. If generation fails, retry with different selectors.
9. Use a seedable pseudo-random number generator so bad boards can be reproduced.

## Direction assignment

Each direction gets two groups.

If opposite selector pairs are chosen, assign them to opposite directions when possible:

- hot vs cold
- polar vs tropical/equatorial
- island vs landlocked
- sea vs land
- horizontal stripes vs vertical stripes

## Ambiguity policy

Avoid active groups that create obvious confusion.  For example, do not place `cold`, `polar`, and `blue_white_exact` on the same board if many selected glyphs would plausibly match multiple groups.

The player should lose because of speed and memory, not because the category map is arguable.
