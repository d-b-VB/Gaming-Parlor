# Product Brief

## Core idea

A single-player abstract game where the player repeatedly performs short, objectively scored skill tests and uses an in-game economy to bet on their own improvement.

The game does not need a narrative wrapper.  It can look like a clean card-table interface built around Hearts, Diamonds, Clubs, and Spades.

## Initial minigame

The first minigame is four-direction sorting.  Each round displays eight groups of four glyphs.  Two groups belong to each direction: up, down, left, and right.  One glyph appears in the center at a time.  The player sends it to the matching direction.

The round score is simply completion time.  Lower is better.

## Player motivation

The player is not just trying to get a high score.  The player is trying to understand when their current ability exceeds the game's memory of their past ability.

When the player improves faster than the memory model updates, Club targets become profitable.  When the player declines or has a bad round, Heart risk appears.

## Emotional loop

1. Learn the board.
2. Enter a flow state.
3. Beat the Club timer and feel overqualified.
4. Raise the personal benchmark.
5. Eventually face pressure from the higher benchmark.
6. Rotate to another game to let the first game's expectations cool.
7. Return to exploit the softened benchmark.
