# UI and Interaction Specification

## Visual style

Use a clean card-table aesthetic.  The game can be abstract.  It does not need character portraits, village trust, quests, or narrative exposition.

## Main play screen

The main sorting screen should include:

- Four directional zones at screen edges.
- Two visible groups per direction.
- Four glyphs per group.
- A center prompt glyph.
- A queue/progress indicator.
- Completion timer.
- Club threshold countdown or marker.
- Heart threshold countdown or marker.
- Current Hearts, Diamonds, Clubs, and Spades.
- Current streak.

## Threshold display

Show two countdown-style targets:

```text
♣ 00:50  Beat this for Clubs
♥ 01:10  Finish before this to avoid damage
```

If the active timer passes the Club threshold, the Club display should visibly expire.  If it passes the Heart threshold, the Heart display should enter danger state.

## Feedback

Correct answer:

- Glyph moves to edge.
- Soft success animation.
- Streak increments.

Wrong answer:

- Glyph starts toward chosen edge.
- Reject animation.
- Streak resets.
- Glyph returns to back of queue.

Club finish:

- Strong positive feedback.
- Show Clubs gained.

Heart loss:

- Clear but not overly punishing visual feedback.
- Show Hearts lost and why.

## Accessibility

- Keyboard-first controls.
- Large directional click zones.
- High-contrast mode should be easy to add.
- Reduced-motion mode should disable long travel animations and use instant movement plus flashes.
- Do not rely only on color to identify correctness.
